import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy Gemini client initialization to avoid startup crashes if key is missing
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// Coach Dr. Mask Pronunciation & Accent Evaluation Endpoint
app.post("/api/coach/analyze", async (req, res) => {
  try {
    const {
      sentence,
      userPhonetic,
      targetAccent,
      feeling,
      recognizedTranscript,
    } = req.body;

    const chosenAccent = targetAccent === "british" ? "British English (Received Pronunciation - RP)" : "General American English (GA)";

    const systemPrompt = `You are "Coach Dr. Mask", a friendly, patient, encouraging, and detail-oriented English pronunciation and voice coach.
The user is participating in an interactive accent training session.
Target Sentence: "${sentence || "I'd like a bottle of water after my morning park run."}"
Target Accent: ${chosenAccent}
User's self-reported phonetic spelling or description of how they said it: "${userPhonetic || ""}"
User's feeling/feedback on how it felt: "${feeling || ""}"
${recognizedTranscript ? `Speech Recognition Transcript: "${recognizedTranscript}"` : ""}

Evaluate the user's pronunciation with warmth, enthusiasm, and scientific precision regarding tongue placement, lip shape, vocal tract mechanics, rhoticity ('R' sound), and flap vs true 'T'.

Respond strictly in JSON matching this schema:
{
  "coachGreeting": "Warm, encouraging 1-2 sentence coach greeting referencing their attempt and how it felt",
  "score": 85, // integer 0-100 indicating accuracy for the chosen accent
  "ratingLabel": "Fantastic Effort!" or "Spot On!" or "Great Foundation!",
  "accentAnalyzed": "American" or "British",
  "rSoundFeedback": {
    "status": "correct" or "needs_adjustment" or "excellent",
    "observation": "Detailed observation on how they handled the 'R' in park, water, after, morning",
    "anatomicalGuidance": "Explicit tongue position instructions (e.g., bunched tongue tip curled back vs relaxed schwa drop)"
  },
  "tSoundFeedback": {
    "status": "correct" or "needs_adjustment" or "excellent",
    "observation": "Detailed observation on flap T vs true T in bottle and water",
    "anatomicalGuidance": "Explicit instructions on alveolar ridge tap vs aspirated release"
  },
  "vowelAndRhythmFeedback": "Observation on vowel quality (e.g. lot-cloth split, trap-bath split, unstressed reductions) and rhythm",
  "wordByWordBreakdown": [
    {
      "word": "water",
      "targetPhonetic": "wah-der" (for GA) or "waw-tuh" (for RP),
      "ipa": "/ˈwɑː.t̬ɚ/" or "/ˈwɔː.tə/",
      "tongueTip": "Quick alveolar tap on 't', tongue curled back on '-er'",
      "lipShape": "Rounded on 'w', relaxed open"
    }
  ],
  "nextDrillTip": "Actionable 1-sentence drill or tongue tip practice for their next attempt"
}`;

    const client = getGeminiClient();

    if (client) {
      try {
        const response = await client.models.generateContent({
          model: "gemini-3.8-flash",
          contents: [
            {
              role: "user",
              parts: [{ text: systemPrompt }],
            },
          ],
          config: {
            responseMimeType: "application/json",
            temperature: 0.4,
          },
        });

        const text = response.text?.trim();
        if (text) {
          const parsed = JSON.parse(text);
          return res.json({ success: true, analysis: parsed });
        }
      } catch (geminiError) {
        console.warn("Gemini API call failed, falling back to rule-based coach analysis:", geminiError);
      }
    }

    // Fallback rule-based Coach Dr. Mask evaluation (guarantees seamless experience even if offline or key is missing)
    const isBritish = targetAccent === "british";
    const lowerPhonetic = (userPhonetic || "").toLowerCase();

    const hasFlapT = lowerPhonetic.includes("wah-der") || lowerPhonetic.includes("wader") || lowerPhonetic.includes("bah-dl") || lowerPhonetic.includes("ba-der");
    const hasTrueT = lowerPhonetic.includes("waw-tuh") || lowerPhonetic.includes("wat-tuh") || lowerPhonetic.includes("bot-uhl") || lowerPhonetic.includes("bot-el");
    const hasRhoticR = lowerPhonetic.includes("pahrk") || lowerPhonetic.includes("park") || lowerPhonetic.includes("mor-ning");
    const hasNonRhotic = lowerPhonetic.includes("pahk") || lowerPhonetic.includes("paw-k") || lowerPhonetic.includes("maw-ning");

    let score = 82;
    if (isBritish) {
      if (hasTrueT) score += 8;
      if (hasNonRhotic) score += 8;
      if (hasFlapT) score -= 8;
    } else {
      if (hasFlapT) score += 8;
      if (hasRhoticR) score += 8;
      if (hasNonRhotic) score -= 6;
    }
    score = Math.max(65, Math.min(98, score));

    const fallbackAnalysis = {
      coachGreeting: `Coach Dr. Mask here! Terrific job taking on this sentence in ${isBritish ? "British English (RP)" : "General American"}. Your awareness of how it felt is the number one secret to vocal progress!`,
      score,
      ratingLabel: score >= 90 ? "Excellent Mastery!" : score >= 80 ? "Solid Progress!" : "Good First Pass!",
      accentAnalyzed: isBritish ? "British" : "American",
      rSoundFeedback: {
        status: (isBritish && hasNonRhotic) || (!isBritish && hasRhoticR) ? "excellent" : "needs_adjustment",
        observation: isBritish
          ? "In British RP, words like 'park' and 'water' drop the rhotic 'R'. 'Park' becomes a rich elongated /pɑːk/ and 'water' ends in a soft schwa /wɔː.tə/."
          : "In General American, every 'R' is strongly rhotic! For 'park' [pɑɹk] and 'morning' [ˈmɔɹ.nɪŋ], your tongue body must stay bunched with strong resonance.",
        anatomicalGuidance: isBritish
          ? "Keep your tongue body resting flat on the floor of your mouth. Do not curl the tongue back—let the vowel open up naturally without friction."
          : "Pull the body of your tongue back towards the back molars. Ensure the tip floats in the middle without touching the roof of your mouth!",
      },
      tSoundFeedback: {
        status: (isBritish && hasTrueT) || (!isBritish && hasFlapT) ? "excellent" : "needs_adjustment",
        observation: isBritish
          ? "For 'bottle of water', British RP keeps the 'T' crisp and aspirated [tʰ], or uses a refined glottal stop. Never turn it into an American 'D'."
          : "In American English, intervocalic 'T' becomes a quick Flap [ɾ]! 'Bottle' feels like 'bah-dl' and 'water' glides as 'wah-der'.",
        anatomicalGuidance: isBritish
          ? "Touch the tip of your tongue firmly against the alveolar ridge behind your upper teeth, build slight air pressure, and release with a sharp puff of air."
          : "Flick the tip of your tongue lightly against the alveolar ridge in one continuous voiced bounce—do not stop the airflow!",
      },
      vowelAndRhythmFeedback: isBritish
        ? "Notice how 'bottle' takes a short rounded 'lot' vowel /ɒ/, and 'water' uses a rounded open back vowel /ɔː/."
        : "American vowels are open: 'bottle' uses the open unrounded /ɑ/ vowel (bah-tl), and 'water' begins with /wɑ/ or /wɔ/ followed by a voiced flap.",
      wordByWordBreakdown: [
        {
          word: "bottle",
          targetPhonetic: isBritish ? "bot-uhl [ˈbɒt.əl]" : "bah-dl [ˈbɑː.t̬əl]",
          ipa: isBritish ? "/ˈbɒt.əl/" : "/ˈbɑː.t̬əl/",
          tongueTip: isBritish ? "Crisp alveolar closure on T, then lateral L" : "Fast tongue bounce against tooth ridge",
          lipShape: isBritish ? "Slightly rounded on 'o'" : "Relaxed jaw drop, open unrounded",
        },
        {
          word: "water",
          targetPhonetic: isBritish ? "waw-tuh [ˈwɔː.tə]" : "wah-der [ˈwɑː.t̬ɚ]",
          ipa: isBritish ? "/ˈwɔː.tə/" : "/ˈwɑː.t̬ɚ/",
          tongueTip: isBritish ? "Firm tap & release on T, tongue drops low on -uh" : "Quick flap tap on T, tongue bunches back for -er",
          lipShape: isBritish ? "Distinct round lips on waw-, neutral relax" : "Slight round to open jaw",
        },
        {
          word: "park",
          targetPhonetic: isBritish ? "pahk [pɑːk]" : "pahrk [pɑɹk]",
          ipa: isBritish ? "/pɑːk/" : "/pɑɹk/",
          tongueTip: isBritish ? "Low and relaxed tongue, elongated /ɑː/" : "Tongue tip curled/bunched back without touching roof",
          lipShape: "Neutral open smile",
        },
      ],
      nextDrillTip: isBritish
        ? "Try saying 'What a lot of water' keeping every 'T' crisp like a gentle click against your upper gum ridge."
        : "Try looping 'better bottle of butter' at 0.8x speed focusing on a gentle voiced tap for every T!",
    };

    return res.json({ success: true, analysis: fallbackAnalysis });
  } catch (error) {
    console.error("Error in /api/coach/analyze:", error);
    res.status(500).json({
      error: "Internal server error analyzing pronunciation",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Human Voice Text-To-Speech endpoint powered by Gemini TTS or fallback synthesis
app.post("/api/coach/tts", async (req, res) => {
  try {
    const { text, accent = "american" } = req.body;
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "Missing or invalid 'text' field" });
    }

    const client = getGeminiClient();
    if (!client) {
      return res.json({
        success: false,
        useClientFallback: true,
        reason: "No Gemini API key available on server, use browser neural human voices",
      });
    }

    // Voice options: 'Kore', 'Puck', 'Fenrir', 'Zephyr', 'Charon'
    // British accent styling or American vocal presence
    const voiceName = accent === "british" ? "Charon" : "Puck";

    // Clean text for speech prompt (remove markdown tags for cleaner pronunciation)
    const cleanedText = text.replace(/[*_#`]/g, "").slice(0, 1000);

    const ttsPrompt = accent === "british"
      ? `Speak clearly with a distinguished, warm, natural British English (RP) accent, articulating true T and smooth non-rhotic vowels: ${cleanedText}`
      : `Speak clearly with an encouraging, energetic, natural General American English accent, articulating clear rhotic R and natural flap T: ${cleanedText}`;

    try {
      const response = await client.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text: ttsPrompt }] }],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      const audioPart = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
      const base64Audio = audioPart?.data;
      const mimeType = audioPart?.mimeType || "audio/wav";

      if (base64Audio) {
        return res.json({
          success: true,
          audioBase64: base64Audio,
          mimeType,
          voiceName,
        });
      }
    } catch (ttsErr) {
      console.warn("Gemini TTS preview attempt failed, signaling client human voice fallback:", ttsErr);
    }

    return res.json({
      success: false,
      useClientFallback: true,
      reason: "TTS generation unavailable, client high-grade speech synthesis active",
    });
  } catch (error) {
    console.error("Error in /api/coach/tts:", error);
    res.status(500).json({
      error: "Failed to generate speech",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Coach Dr. Mask Q&A, Grammar & Accent Mistake Detective Endpoint
app.post("/api/coach/ask", async (req, res) => {
  try {
    const { question, targetAccent = "american", chatHistory = [] } = req.body;

    if (!question || typeof question !== "string") {
      return res.status(400).json({ error: "Missing or invalid 'question' field" });
    }

    const chosenAccent = targetAccent === "british" ? "British English (Received Pronunciation - RP)" : "General American English (GA)";

    const systemPrompt = `You are "Coach Dr. Mask", an elite, approachable, warmly encouraging English vocal coach, linguist, and grammar mentor.
The learner is practicing in ${chosenAccent}.
Learner's Question / Statement: "${question}"

CRITICAL DIRECTIVES:
1. ANSWER ANY QUESTION: Answer whatever the user asks with clarity, deep vocal/linguistic insight, practical examples, and encouraging mentorship. They can ask about grammar, idiom meanings, pronunciation differences (GA vs RP), mouth mechanics, tongue positions, conversational phrasing, or general English rules.
2. DETECT & PROMPT ON MISTAKES:
   - Check if the user's input contains any GRAMMAR mistakes (e.g. tense disagreement, preposition errors, subject-verb mistakes, missing articles, word order, double negatives).
   - Check if the user's input or phonetic description contains any ACCENT or PRONUNCIATION confusions (e.g. using American rhotic R when aiming for British RP, using Flap T instead of True T in British, confusing vowel splits like trap/bath or lot/cloth, or spelling things phonetically incorrect).
   - If there is a mistake, be proactive, kind, and specific: alert them directly, explain WHY it is a mistake, offer the exact correction, and give an anatomical/vocal tongue-placement tip.
   - If their sentence is grammatically flawless and phonetically on point, celebrate it warmly!

Respond STRICTLY in JSON with this exact schema:
{
  "coachAnswer": "Your comprehensive, friendly, coach answer addressing their question directly in 2-4 sentences. Include phonetic tips if applicable.",
  "grammarCorrectedSentence": "The user's sentence with grammar/usage corrected, or null if no grammar errors",
  "mistakes": [
    {
      "type": "grammar" | "accent" | "pronunciation" | "vocabulary",
      "severity": "correction" | "suggestion" | "praise",
      "originalPart": "the mistaken word or phrase",
      "correctedPart": "the correct English equivalent",
      "explanation": "Clear, friendly explanation of why this was a mistake and how to remember it",
      "anatomicalTip": "Practical tongue/mouth/jaw advice (e.g. 'Keep your tongue down', 'Don't curl R here')",
      "accentContext": "American" | "British" | "Universal"
    }
  ],
  "accentGuidance": "1-2 sentences highlighting how to say their phrase with authentic ${chosenAccent} rhythm and intonation",
  "suggestedFollowUp": "A recommended follow-up drill or question the user can ask Coach Dr. Mask next"
}`;

    const client = getGeminiClient();

    if (client) {
      try {
        const promptContents: any[] = [];

        // Add contextual conversation history if available
        if (Array.isArray(chatHistory) && chatHistory.length > 0) {
          const recentHistory = chatHistory.slice(-4);
          for (const msg of recentHistory) {
            promptContents.push({
              role: msg.sender === "user" ? "user" : "model",
              parts: [{ text: msg.text || "" }],
            });
          }
        }

        promptContents.push({
          role: "user",
          parts: [{ text: `${systemPrompt}\n\nUser Input to Analyze:\n${question}` }],
        });

        const response = await client.models.generateContent({
          model: "gemini-3.8-flash",
          contents: promptContents,
          config: {
            responseMimeType: "application/json",
            temperature: 0.35,
          },
        });

        const text = response.text?.trim();
        if (text) {
          const parsed = JSON.parse(text);
          return res.json({ success: true, result: parsed });
        }
      } catch (geminiError) {
        console.warn("Gemini API call for /api/coach/ask failed, falling back:", geminiError);
      }
    }

    // Fallback rule-based analysis if offline or Gemini key missing
    const isBritish = targetAccent === "british";
    const lower = question.toLowerCase();

    const detectedMistakes: any[] = [];
    let corrected = question;

    // Common grammar checks
    if (/\bi is\b/i.test(question)) {
      detectedMistakes.push({
        type: "grammar",
        severity: "correction",
        originalPart: "I is",
        correctedPart: "I am",
        explanation: "Subject-verb agreement: with the first-person singular 'I', always pair with 'am' in the present tense, never 'is'.",
        anatomicalTip: "Link 'I' and 'am' smoothly with a gentle /j/ glide: 'Eye-yam'.",
        accentContext: "Universal",
      });
      corrected = corrected.replace(/\bi is\b/gi, "I am");
    }

    if (/\bhe don'?t\b/i.test(question)) {
      detectedMistakes.push({
        type: "grammar",
        severity: "correction",
        originalPart: "he don't",
        correctedPart: "he doesn't",
        explanation: "Third-person singular takes 'does not' / 'doesn't' in standard English.",
        anatomicalTip: "Keep the 'z' sound voiced in 'doesn't' with vocal cord vibration.",
        accentContext: "Universal",
      });
      corrected = corrected.replace(/\bhe don'?t\b/gi, "he doesn't");
    }

    if (/\bmore better\b/i.test(question)) {
      detectedMistakes.push({
        type: "grammar",
        severity: "correction",
        originalPart: "more better",
        correctedPart: "much better" or "better",
        explanation: "'Better' is already a comparative adjective; pairing it with 'more' creates a double comparative.",
        anatomicalTip: "Focus on the vowel in 'better'—crisp true T in RP or flap T in GA.",
        accentContext: "Universal",
      });
      corrected = corrected.replace(/\bmore better\b/gi, "much better");
    }

    // Accent-specific checks
    if (isBritish && (lower.includes("wah-der") || lower.includes("bah-dl") || lower.includes("wader"))) {
      detectedMistakes.push({
        type: "accent",
        severity: "correction",
        originalPart: "wah-der / bah-dl (Flap T)",
        correctedPart: "waw-tuh / bot-uhl (Crisp True T)",
        explanation: "In British RP, flapping the 'T' into a 'D' sounds American. True British T requires a firm alveolar contact and gentle release of air.",
        anatomicalTip: "Seal your tongue tip firmly behind your upper incisors and release with a light puff of air: /tʰ/.",
        accentContext: "British",
      });
    }

    if (!isBritish && (lower.includes("pahk") || lower.includes("waw-tuh"))) {
      detectedMistakes.push({
        type: "accent",
        severity: "correction",
        originalPart: "pahk / waw-tuh (Non-rhotic drop)",
        correctedPart: "pahrk / wah-der (Strong Rhotic R)",
        explanation: "In General American, the 'R' is fully pronounced. Dropping the 'R' sounds British or regional.",
        anatomicalTip: "Bunch your tongue body back against your upper molars and let the sound resonate deeply.",
        accentContext: "American",
      });
    }

    const fallbackAnswer = {
      coachAnswer: `Coach Dr. Mask here! Regarding your question: in ${isBritish ? "British English (RP)" : "General American"}, clear enunciation comes from mastering vowel posture and breath support. Keep your jaw relaxed and let your tongue lead the articulation.`,
      grammarCorrectedSentence: detectedMistakes.length > 0 ? corrected : null,
      mistakes: detectedMistakes.length > 0 ? detectedMistakes : [
        {
          type: "pronunciation",
          severity: "praise",
          originalPart: question.slice(0, 30),
          correctedPart: question.slice(0, 30),
          explanation: "Great phrasing! Your sentence structure is clear and communicative.",
          anatomicalTip: isBritish
            ? "Maintain an upright posture and crisp alveolar contacts for a polished RP sound."
            : "Keep a relaxed jaw and strong rhotic resonance for authentic American flow.",
          accentContext: isBritish ? "British" : "American",
        }
      ],
      accentGuidance: isBritish
        ? "In British RP, aim for higher vocal placement and crisp consonant releases at word endings."
        : "In General American, focus on connected speech linking and voiced flap transitions.",
      suggestedFollowUp: "Ask me: 'How do I pronounce the trap-bath split in words like path and dance?'",
    };

    return res.json({ success: true, result: fallbackAnswer });
  } catch (error) {
    console.error("Error in /api/coach/ask:", error);
    res.status(500).json({
      error: "Failed to process question",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
});


async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Coach Dr. Mask server running on port ${PORT}`);
  });
}

startServer();
