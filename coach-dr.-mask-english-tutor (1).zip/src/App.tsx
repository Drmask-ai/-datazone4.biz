import React, { useState } from 'react';
import { AvatarCoach3D } from './components/AvatarCoach3D';
import { MouthAnatomyGuide } from './components/MouthAnatomyGuide';
import { InteractiveCoachingSession } from './components/InteractiveCoachingSession';
import { DrillSelector } from './components/DrillSelector';
import { AccentType, VisemeType, PracticeSentence } from './types';
import { FEATURED_SENTENCE } from './data/curriculum';
import { Sparkles, Headphones, BookOpen, Volume2, ShieldCheck } from 'lucide-react';

export default function App() {
  const [targetAccent, setTargetAccent] = useState<AccentType>('american');
  const [currentViseme, setCurrentViseme] = useState<VisemeType>('smile');
  const [isCoachSpeaking, setIsCoachSpeaking] = useState<boolean>(false);
  const [isCoachListening, setIsCoachListening] = useState<boolean>(false);
  const [coachStatusText, setCoachStatusText] = useState<string>(
    "Welcome! Today, we're going to master the key differences between British English (Received Pronunciation) and General American English. We will work on your accent, rhythm, mouth positioning, and natural phrasing."
  );
  const [selectedSentence, setSelectedSentence] = useState<PracticeSentence>(FEATURED_SENTENCE);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Studio Header Bar */}
      <header className="sticky top-0 z-50 bg-slate-900/85 backdrop-blur-md border-b border-slate-800 px-4 sm:px-8 py-3.5 shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-teal-600 to-emerald-500 flex items-center justify-center text-white shadow-lg shadow-cyan-600/20">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-white">
                  Coach Dr. Mask
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold bg-cyan-500/10 text-cyan-300 rounded-full border border-cyan-500/30">
                  Interactive Accent Studio
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                3D Animated Vocal Coach • General American (GA) vs British (RP)
              </p>
            </div>
          </div>

          {/* Quick Accent Selector in Header */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400 font-medium hidden md:inline-block">Mastery Target:</span>
            <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
              <button
                id="header-select-us-btn"
                onClick={() => setTargetAccent('american')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  targetAccent === 'american'
                    ? 'bg-blue-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                🇺🇸 American
              </button>
              <button
                id="header-select-uk-btn"
                onClick={() => setTargetAccent('british')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  targetAccent === 'british'
                    ? 'bg-rose-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                🇬🇧 British
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Studio Canvas */}
      <main className="max-w-7xl mx-auto px-4 sm:px-8 py-6 sm:py-8 space-y-8">
        {/* Top Motivational Intro Tag */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                Live Coaching Session
              </span>
              <span className="text-xs text-slate-500">•</span>
              <span className="text-xs text-slate-300 font-medium">
                The 'R' Sound & Flap T vs True T Mastery
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300">
              Follow Coach Dr. Mask's lip and tongue placements, speak the sentence aloud or phonetically, and receive personalized voice mechanics feedback.
            </p>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <div className="px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center space-x-2 text-xs text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Phonetic & Voice Analysis Active</span>
            </div>
          </div>
        </div>

        {/* 2-Column Responsive Studio Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: 3D Animated Coach Dr. Mask & Vocal Tract Anatomy */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-20">
            {/* 3D Animated Avatar */}
            <AvatarCoach3D
              currentViseme={currentViseme}
              isSpeaking={isCoachSpeaking}
              isListening={isCoachListening}
              coachStatusText={coachStatusText}
              targetAccent={targetAccent}
              onAccentChange={(newAccent) => setTargetAccent(newAccent)}
            />

            {/* Visual Lip & Tongue Placement Anatomical Guide */}
            <MouthAnatomyGuide
              currentAccent={targetAccent}
              onAccentChange={(newAccent) => setTargetAccent(newAccent)}
            />
          </div>

          {/* Right Column: Interactive Sentence Practice, Recording, & Coach Feedback */}
          <div className="lg:col-span-7 space-y-6">
            {/* Interactive Session Form & Results */}
            <InteractiveCoachingSession
              currentSentence={selectedSentence}
              targetAccent={targetAccent}
              onAccentChange={(newAccent) => setTargetAccent(newAccent)}
              onCoachSpeakingChange={setIsCoachSpeaking}
              onCoachListeningChange={setIsCoachListening}
              onUpdateCoachStatus={setCoachStatusText}
            />

            {/* Drill Selector for Extended Practice */}
            <DrillSelector
              selectedSentence={selectedSentence}
              onSelectSentence={(sentence) => {
                setSelectedSentence(sentence);
                setCoachStatusText(`Let's practice: "${sentence.sentence}". ${sentence.coachAdvice}`);
              }}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-12 py-6 border-t border-slate-800 text-center text-xs text-slate-500">
        <p>
          Coach Dr. Mask English Tutor • General American & British RP Accent Coaching Studio
        </p>
      </footer>
    </div>
  );
}
