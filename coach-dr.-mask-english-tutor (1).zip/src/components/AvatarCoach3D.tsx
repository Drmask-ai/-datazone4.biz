import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, Sparkles, Smile, MessageSquare, Play, RotateCcw, VolumeX } from 'lucide-react';
import { VisemeType, AccentType } from '../types';
import { speakWithCoach, stopCoachSpeech } from '../utils/audioSpeech';

interface AvatarCoach3DProps {
  currentViseme?: VisemeType;
  isSpeaking?: boolean;
  isListening?: boolean;
  coachStatusText?: string;
  targetAccent: AccentType;
  onAccentChange?: (accent: AccentType) => void;
  className?: string;
}

export const AvatarCoach3D: React.FC<AvatarCoach3DProps> = ({
  currentViseme = 'smile',
  isSpeaking = false,
  isListening = false,
  coachStatusText = "Welcome! Today, we're going to master the key differences between British English and General American English.",
  targetAccent,
  onAccentChange,
  className = '',
}) => {
  const [blinking, setBlinking] = useState(false);
  const [nodding, setNodding] = useState(false);
  const [leaningForward, setLeaningForward] = useState(true);
  const [internalSpeaking, setInternalSpeaking] = useState(false);
  const [activeViseme, setActiveViseme] = useState<VisemeType>(currentViseme);
  const [speechRate, setSpeechRate] = useState<number>(1.0);

  // Sync external viseme changes
  useEffect(() => {
    setActiveViseme(currentViseme);
  }, [currentViseme]);

  // Periodic natural blinking
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlinking(true);
      setTimeout(() => setBlinking(false), 180);
    }, 3800);
    return () => clearInterval(blinkInterval);
  }, []);

  // Periodic subtle nodding when encouraging or listening
  useEffect(() => {
    if (isListening || isSpeaking) {
      setNodding(true);
      const timer = setTimeout(() => setNodding(false), 1200);
      return () => clearTimeout(timer);
    }
  }, [isListening, isSpeaking]);

  const speakingState = isSpeaking || internalSpeaking;

  const handleQuickPlayGreeting = (accent: AccentType) => {
    setInternalSpeaking(true);
    speakWithCoach(
      coachStatusText,
      accent,
      {
        rate: speechRate,
        onViseme: (v) => setActiveViseme(v),
        onEnd: () => {
          setInternalSpeaking(false);
          setActiveViseme('smile');
        },
      }
    );
  };

  const handleStopSpeech = () => {
    stopCoachSpeech();
    setInternalSpeaking(false);
    setActiveViseme('smile');
  };

  // Viseme mouth rendering parameters
  const renderMouthShape = () => {
    switch (activeViseme) {
      case 'open_A':
        return (
          <g>
            {/* Open mouth for Ah sound */}
            <ellipse cx="100" cy="132" rx="14" ry="11" fill="#450a0a" stroke="#be123c" strokeWidth="2" />
            <path d="M 90 126 Q 100 128 110 126" stroke="#ffffff" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            <ellipse cx="100" cy="138" rx="8" ry="4" fill="#fb7185" />
          </g>
        );
      case 'open_O':
        return (
          <g>
            {/* Rounded O mouth */}
            <ellipse cx="100" cy="132" rx="10" ry="12" fill="#450a0a" stroke="#be123c" strokeWidth="2" />
            <ellipse cx="100" cy="132" rx="6" ry="8" fill="#1c1917" />
          </g>
        );
      case 'rounded_W':
        return (
          <g>
            {/* Tightly rounded forward puckered lips */}
            <circle cx="100" cy="132" r="7" fill="#450a0a" stroke="#be123c" strokeWidth="2.5" />
            <circle cx="100" cy="132" r="3.5" fill="#1c1917" />
          </g>
        );
      case 'tongue_T':
        return (
          <g>
            {/* Tongue tip touching alveolar ridge behind upper teeth */}
            <path d="M 88 128 Q 100 134 112 128 Q 100 142 88 128 Z" fill="#450a0a" stroke="#be123c" strokeWidth="2" />
            {/* Upper teeth */}
            <path d="M 92 127 L 108 127" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
            {/* Tongue tip touching upper ridge */}
            <path d="M 96 132 Q 100 127 104 132" fill="#f43f5e" stroke="#fb7185" strokeWidth="2.5" />
          </g>
        );
      case 'bunched_R':
        return (
          <g>
            {/* Bunched retroflex tongue shape */}
            <path d="M 88 128 Q 100 132 112 128 Q 100 140 88 128 Z" fill="#450a0a" stroke="#be123c" strokeWidth="2" />
            <path d="M 91 127 L 109 127" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
            {/* Tongue pulled back in center cavity */}
            <ellipse cx="100" cy="135" rx="7" ry="3.5" fill="#f43f5e" />
          </g>
        );
      case 'wide_E':
        return (
          <g>
            {/* Wide smiling mouth for /iː/ or /e/ */}
            <path d="M 85 130 Q 100 136 115 130 Q 100 138 85 130 Z" fill="#450a0a" stroke="#be123c" strokeWidth="2" />
            <path d="M 88 130 L 112 130" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          </g>
        );
      case 'neutral':
        return (
          <g>
            <path d="M 89 132 Q 100 133 111 132" stroke="#9f1239" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          </g>
        );
      case 'smile':
      default:
        return (
          <g>
            {/* Warm encouraging coach smile with slight teeth peek */}
            <path d="M 86 128 Q 100 141 114 128" fill="#450a0a" stroke="#be123c" strokeWidth="2" />
            <path d="M 90 129 Q 100 132 110 129" stroke="#ffffff" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            <path d="M 84 126 Q 86 129 88 131" stroke="#be123c" strokeWidth="1.5" strokeLinecap="round" fill="none" />
            <path d="M 116 126 Q 114 129 112 131" stroke="#be123c" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          </g>
        );
    }
  };

  return (
    <div className={`relative flex flex-col items-center ${className}`}>
      {/* 3D Stage Container */}
      <div className="relative w-full max-w-md rounded-2xl bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950 p-6 shadow-2xl border border-slate-700/60 overflow-hidden">
        {/* Ambient Studio Lighting Glows */}
        <div className="absolute -top-16 -left-16 w-48 h-48 rounded-full bg-cyan-500/20 blur-3xl pointer-events-none" />
        <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-emerald-500/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 inset-x-10 h-24 bg-blue-500/10 blur-2xl pointer-events-none" />

        {/* Top Coach Header Bar */}
        <div className="relative flex items-center justify-between pb-3 border-b border-slate-700/60">
          <div className="flex items-center space-x-2.5">
            <div className="relative">
              <span className="flex h-3 w-3">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${speakingState ? 'bg-emerald-400' : 'bg-cyan-400'}`} />
                <span className={`relative inline-flex rounded-full h-3 w-3 ${speakingState ? 'bg-emerald-500' : 'bg-cyan-500'}`} />
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-slate-100 tracking-tight">Coach Dr. Mask</h3>
                <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
                  3D LIVE AVATAR
                </span>
              </div>
              <p className="text-[11px] text-slate-400">American & British Voice Coach</p>
            </div>
          </div>

          {/* Posture & Mood Controls */}
          <div className="flex items-center space-x-1.5">
            <button
              id="coach-lean-forward-btn"
              onClick={() => setLeaningForward(!leaningForward)}
              title="Toggle Lean Forward Posture"
              className={`px-2 py-1 text-[11px] rounded-md font-medium transition-colors ${
                leaningForward
                  ? 'bg-cyan-600/30 text-cyan-300 border border-cyan-500/40'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Leaning In
            </button>
            <button
              id="coach-nod-btn"
              onClick={() => {
                setNodding(true);
                setTimeout(() => setNodding(false), 1200);
              }}
              title="Trigger Coach Nod"
              className="px-2 py-1 text-[11px] rounded-md font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 transition-colors"
            >
              Nod
            </button>
          </div>
        </div>

        {/* 3D Character Canvas & Motion Stage */}
        <div className="relative my-4 flex justify-center items-center">
          {/* Radial Audio Visualizer Ripple Effect */}
          {speakingState && (
            <motion.div
              animate={{ scale: [1, 1.18, 1], opacity: [0.35, 0.7, 0.35] }}
              transition={{ repeat: Infinity, duration: 1.2, ease: 'easeInOut' }}
              className="absolute w-60 h-60 rounded-full border-2 border-emerald-400/40 bg-emerald-500/10 pointer-events-none"
            />
          )}

          {isListening && (
            <motion.div
              animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.8, 0.4] }}
              transition={{ repeat: Infinity, duration: 1.0, ease: 'easeInOut' }}
              className="absolute w-60 h-60 rounded-full border-2 border-amber-400/50 bg-amber-500/10 pointer-events-none"
            />
          )}

          {/* 3D Animated Avatar Head & Torso Rig */}
          <motion.div
            animate={{
              y: nodding ? [0, 8, -2, 4, 0] : [0, -3, 0],
              scale: leaningForward ? 1.05 : 1.0,
              rotateX: leaningForward ? 5 : 0,
            }}
            transition={{
              y: nodding ? { duration: 1.1 } : { repeat: Infinity, duration: 3.5, ease: 'easeInOut' },
              scale: { duration: 0.4 },
            }}
            className="relative w-52 h-56 flex items-center justify-center filter drop-shadow-xl select-none"
            style={{ perspective: 800 }}
          >
            <svg
              viewBox="0 0 200 200"
              className="w-full h-full"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                {/* 3D Shading Gradients */}
                <linearGradient id="faceGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#fed7aa" />
                  <stop offset="50%" stopColor="#fdba74" />
                  <stop offset="100%" stopColor="#fb923c" />
                </linearGradient>

                <linearGradient id="jacketGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#1e293b" />
                  <stop offset="100%" stopColor="#0f172a" />
                </linearGradient>

                <linearGradient id="hairGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#1c1917" />
                  <stop offset="50%" stopColor="#292524" />
                  <stop offset="100%" stopColor="#1c1917" />
                </linearGradient>

                <linearGradient id="glassesRim" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#38bdf8" />
                  <stop offset="100%" stopColor="#818cf8" />
                </linearGradient>

                <filter id="shadow3D" x="-10%" y="-10%" width="130%" height="130%">
                  <feDropShadow dx="0" dy="4" stdDeviation="4" floodOpacity="0.3" />
                </filter>
              </defs>

              {/* Shoulders & Coach Blazer */}
              <g id="avatar-torso">
                <path
                  d="M 35 200 L 45 168 Q 65 152 100 152 Q 135 152 155 168 L 165 200 Z"
                  fill="url(#jacketGrad)"
                  stroke="#334155"
                  strokeWidth="2"
                />
                {/* Crisp Shirt Collar */}
                <path d="M 85 152 L 100 172 L 115 152 Z" fill="#f8fafc" />
                {/* Smart Teal Coach Tie / Accent */}
                <path d="M 97 172 L 103 172 L 105 198 L 95 198 Z" fill="#0d9488" />
                {/* Blazer Lapels */}
                <path d="M 72 153 L 88 185 L 68 200" stroke="#475569" strokeWidth="2.5" fill="none" />
                <path d="M 128 153 L 112 185 L 132 200" stroke="#475569" strokeWidth="2.5" fill="none" />
              </g>

              {/* Neck */}
              <rect x="88" y="132" width="24" height="26" rx="6" fill="#fb923c" />
              {/* Neck shadow under chin */}
              <ellipse cx="100" cy="136" rx="14" ry="4" fill="#ea580c" opacity="0.35" />

              {/* Ears */}
              <ellipse cx="56" cy="104" rx="7" ry="12" fill="#fdba74" />
              <ellipse cx="144" cy="104" rx="7" ry="12" fill="#fdba74" />

              {/* Head / Face Shape */}
              <g id="avatar-head" filter="url(#shadow3D)">
                <ellipse cx="100" cy="104" rx="44" ry="48" fill="url(#faceGrad)" />
                {/* Cheek highlights */}
                <circle cx="74" cy="116" r="7" fill="#fb7185" opacity="0.25" />
                <circle cx="126" cy="116" r="7" fill="#fb7185" opacity="0.25" />
              </g>

              {/* Stylized Modern Hair */}
              <g id="avatar-hair">
                <path
                  d="M 56 94 Q 52 64 80 54 Q 100 48 126 56 Q 146 64 144 94 Q 134 76 118 72 Q 95 68 76 76 Q 64 82 56 94 Z"
                  fill="url(#hairGrad)"
                />
                <path d="M 75 56 Q 95 50 115 54" stroke="#44403c" strokeWidth="3" fill="none" />
              </g>

              {/* Eyebrows */}
              <g id="avatar-eyebrows">
                <motion.path
                  animate={{ y: speakingState ? -2 : 0 }}
                  transition={{ repeat: Infinity, duration: 0.8, repeatType: 'reverse' }}
                  d="M 68 84 Q 78 80 88 84"
                  stroke="#292524"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  fill="none"
                />
                <motion.path
                  animate={{ y: speakingState ? -2 : 0 }}
                  transition={{ repeat: Infinity, duration: 0.8, repeatType: 'reverse' }}
                  d="M 112 84 Q 122 80 132 84"
                  stroke="#292524"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  fill="none"
                />
              </g>

              {/* Eyes with Realistic Blinking */}
              <g id="avatar-eyes">
                {blinking ? (
                  <>
                    <path d="M 68 96 Q 78 100 88 96" stroke="#292524" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 112 96 Q 122 100 132 96" stroke="#292524" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                  </>
                ) : (
                  <>
                    {/* Left Eye */}
                    <ellipse cx="78" cy="96" rx="8" ry="6" fill="#ffffff" stroke="#e2e8f0" strokeWidth="1" />
                    <circle cx="78" cy="96" r="4" fill="#0284c7" />
                    <circle cx="78" cy="96" r="2.2" fill="#0f172a" />
                    <circle cx="79.5" cy="94.5" r="1.2" fill="#ffffff" />

                    {/* Right Eye */}
                    <ellipse cx="122" cy="96" rx="8" ry="6" fill="#ffffff" stroke="#e2e8f0" strokeWidth="1" />
                    <circle cx="122" cy="96" r="4" fill="#0284c7" />
                    <circle cx="122" cy="96" r="2.2" fill="#0f172a" />
                    <circle cx="123.5" cy="94.5" r="1.2" fill="#ffffff" />
                  </>
                )}
              </g>

              {/* Designer Glasses Frame */}
              <g id="avatar-glasses">
                <rect x="65" y="86" width="26" height="20" rx="5" fill="none" stroke="url(#glassesRim)" strokeWidth="2.5" />
                <rect x="109" y="86" width="26" height="20" rx="5" fill="none" stroke="url(#glassesRim)" strokeWidth="2.5" />
                <path d="M 91 94 L 109 94" stroke="url(#glassesRim)" strokeWidth="2.5" strokeLinecap="round" />
                <path d="M 65 92 L 56 90" stroke="url(#glassesRim)" strokeWidth="2" strokeLinecap="round" />
                <path d="M 135 92 L 144 90" stroke="url(#glassesRim)" strokeWidth="2" strokeLinecap="round" />
                {/* Lens Reflection */}
                <path d="M 68 89 L 75 89" stroke="#ffffff" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
                <path d="M 112 89 L 119 89" stroke="#ffffff" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
              </g>

              {/* Nose */}
              <path d="M 98 102 Q 100 114 96 116 Q 100 118 104 116" stroke="#ea580c" strokeWidth="2" fill="none" strokeLinecap="round" />

              {/* Dynamic Animated Mouth / Viseme */}
              <g id="avatar-mouth">
                {renderMouthShape()}
              </g>

              {/* Small Doctor Lapel Badge */}
              <rect x="125" y="172" width="24" height="12" rx="2" fill="#0284c7" />
              <text x="137" y="180" fill="#ffffff" fontSize="6" fontWeight="bold" textAnchor="middle">
                DR. MASK
              </text>
            </svg>
          </motion.div>
        </div>

        {/* Dynamic Mouth Shape Label Pill */}
        <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-slate-950/70 border border-slate-800 text-[11px] mb-3">
          <div className="flex items-center space-x-1.5">
            <span className="text-slate-400">Current Viseme:</span>
            <span className="font-mono font-semibold text-cyan-300">
              {activeViseme.toUpperCase().replace('_', ' ')}
            </span>
          </div>
          <div className="flex items-center space-x-1">
            <span className={`w-2 h-2 rounded-full ${speakingState ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
            <span className="text-slate-400">{speakingState ? 'Articulating' : 'Ready'}</span>
          </div>
        </div>

        {/* Coach Live Statement Bubble */}
        <div className="relative rounded-xl bg-slate-800/90 border border-slate-700/80 p-3.5 mb-3 shadow-inner">
          <div className="flex items-start space-x-2.5">
            <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs leading-relaxed text-slate-200">
                "{coachStatusText}"
              </p>
            </div>
          </div>
        </div>

        {/* Interactive Speech & Accent Demo Buttons */}
        <div className="flex flex-col space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button
              id="coach-speak-us-btn"
              onClick={() => {
                onAccentChange?.('american');
                handleQuickPlayGreeting('american');
              }}
              disabled={speakingState}
              className={`flex items-center justify-center space-x-2 px-3 py-2.5 rounded-xl font-semibold text-xs transition-all shadow-md ${
                targetAccent === 'american'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-blue-500/20 ring-2 ring-blue-400/40'
                  : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              <Volume2 className="w-4 h-4" />
              <span>Speak American (GA)</span>
            </button>

            <button
              id="coach-speak-uk-btn"
              onClick={() => {
                onAccentChange?.('british');
                handleQuickPlayGreeting('british');
              }}
              disabled={speakingState}
              className={`flex items-center justify-center space-x-2 px-3 py-2.5 rounded-xl font-semibold text-xs transition-all shadow-md ${
                targetAccent === 'british'
                  ? 'bg-gradient-to-r from-rose-600 to-amber-600 text-white shadow-rose-500/20 ring-2 ring-rose-400/40'
                  : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              <Volume2 className="w-4 h-4" />
              <span>Speak British (RP)</span>
            </button>
          </div>

          {speakingState && (
            <button
              id="coach-stop-speech-btn"
              onClick={handleStopSpeech}
              className="flex items-center justify-center space-x-1.5 w-full py-1.5 rounded-lg bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs font-medium hover:bg-rose-900/60 transition-colors"
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span>Stop Speaking</span>
            </button>
          )}

          {/* Speed Selector */}
          <div className="flex items-center justify-between pt-1 px-1 text-[11px] text-slate-400">
            <span>Demonstration Speed:</span>
            <div className="flex items-center space-x-1.5">
              {[0.75, 1.0, 1.15].map((rate) => (
                <button
                  key={rate}
                  onClick={() => setSpeechRate(rate)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                    speechRate === rate
                      ? 'bg-cyan-500/30 text-cyan-300 font-bold border border-cyan-500/40'
                      : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
