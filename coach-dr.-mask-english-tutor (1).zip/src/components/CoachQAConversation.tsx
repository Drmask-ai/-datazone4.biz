import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  MessageSquare,
  Send,
  Sparkles,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  RotateCcw,
  Zap,
  BookOpen,
} from 'lucide-react';
import { AccentType, CoachMessage, MistakeAlert } from '../types';
import { speakWithCoach, stopCoachSpeech } from '../utils/audioSpeech';

interface CoachQAConversationProps {
  targetAccent: AccentType;
  onAccentChange: (accent: AccentType) => void;
  onCoachSpeakingChange: (isSpeaking: boolean) => void;
  onCoachListeningChange: (isListening: boolean) => void;
  onUpdateCoachStatus: (text: string) => void;
  className?: string;
}

const INITIAL_MESSAGES: CoachMessage[] = [
  {
    id: 'welcome-msg',
    sender: 'coach',
    text: "Hello! I am Coach Dr. Mask. Ask me ANY question about English grammar, vocabulary, pronunciation, or American vs British accent differences! Speak or type naturally—if you make any grammar or accent mistakes, I'll gently prompt you with the exact correction and mouth mechanics.",
    timestamp: 'Just now',
    accentGuidance: 'Tip: You can ask about grammar rules, or practice saying tricky sentences!',
    mistakes: [],
  },
];

const PROMPT_SUGGESTIONS = [
  "How do I say 'bottle of water' without sounding unnatural?",
  "Is 'He don't know nothing' correct grammar?",
  "Why is 'R' silent in British park, but loud in American?",
  "Can you check if my grammar is right: 'I been waiting here since two hours'?",
  "What's the difference between /æ/ in 'cat' and /ɑː/ in 'father'?",
];

export const CoachQAConversation: React.FC<CoachQAConversationProps> = ({
  targetAccent,
  onAccentChange,
  onCoachSpeakingChange,
  onCoachListeningChange,
  onUpdateCoachStatus,
  className = '',
}) => {
  const [messages, setMessages] = useState<CoachMessage[]>(INITIAL_MESSAGES);
  const [inputQuestion, setInputQuestion] = useState<string>('');
  const [isAsking, setIsAsking] = useState<boolean>(false);
  const [isVoiceInputActive, setIsVoiceInputActive] = useState<boolean>(false);
  const [activeAudioMessageId, setActiveAudioMessageId] = useState<string | null>(null);

  const chatContainerRef = useRef<HTMLDivElement | null>(null);
  const speechRecognitionRef = useRef<any>(null);

  // Auto-scroll chat to latest message
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isAsking]);

  // Handle playing message with Coach Dr. Mask's human voice
  const handlePlayMessageVoice = async (msg: CoachMessage) => {
    if (activeAudioMessageId === msg.id) {
      stopCoachSpeech();
      setActiveAudioMessageId(null);
      onCoachSpeakingChange(false);
      return;
    }

    stopCoachSpeech();
    setActiveAudioMessageId(msg.id);
    onCoachSpeakingChange(true);
    onUpdateCoachStatus(msg.text.slice(0, 120) + '...');

    const speechAccent = msg.accent || targetAccent;

    // Compose spoken text: coach answer + highlight any mistake prompt clearly
    let spokenContent = msg.text;
    if (msg.mistakes && msg.mistakes.length > 0) {
      const topCorrection = msg.mistakes[0];
      if (topCorrection.severity === 'correction') {
        spokenContent += ` Note on ${topCorrection.type}: instead of ${topCorrection.originalPart || 'that'}, say ${topCorrection.correctedPart || ''}. ${topCorrection.anatomicalTip || ''}`;
      }
    }

    await speakWithCoach(spokenContent, speechAccent, {
      onEnd: () => {
        setActiveAudioMessageId(null);
        onCoachSpeakingChange(false);
      },
    });
  };

  // Voice speech recognition for asking questions directly by speaking
  const toggleVoiceQuestion = () => {
    if (isVoiceInputActive) {
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.stop();
      }
      setIsVoiceInputActive(false);
      onCoachListeningChange(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. You can type your question directly!");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = targetAccent === 'british' ? 'en-GB' : 'en-US';
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setIsVoiceInputActive(true);
        onCoachListeningChange(true);
        onUpdateCoachStatus("Listening to your question... Speak naturally!");
      };

      recognition.onresult = (e: any) => {
        const transcript = Array.from(e.results)
          .map((res: any) => res[0].transcript)
          .join('');
        setInputQuestion(transcript);
      };

      recognition.onerror = (err: any) => {
        console.warn("Speech recognition notice:", err);
        setIsVoiceInputActive(false);
        onCoachListeningChange(false);
      };

      recognition.onend = () => {
        setIsVoiceInputActive(false);
        onCoachListeningChange(false);
      };

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error("Speech recognition error:", err);
      setIsVoiceInputActive(false);
      onCoachListeningChange(false);
    }
  };

  // Submit question to Coach Dr. Mask
  const handleSendQuestion = async (overrideText?: string) => {
    const textToSend = (overrideText !== undefined ? overrideText : inputQuestion).trim();
    if (!textToSend || isAsking) return;

    // Add user question to chat
    const userMsg: CoachMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuestion('');
    setIsAsking(true);
    onCoachListeningChange(true);
    onUpdateCoachStatus(`Analyzing your question and inspecting grammar & accent: "${textToSend.slice(0, 50)}..."`);

    try {
      const response = await fetch('/api/coach/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: textToSend,
          targetAccent,
          chatHistory: messages.slice(-6),
        }),
      });

      const data = await response.json();
      if (data.success && data.result) {
        const coachMsg: CoachMessage = {
          id: `coach-${Date.now()}`,
          sender: 'coach',
          text: data.result.coachAnswer,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          accent: targetAccent,
          mistakes: data.result.mistakes || [],
          grammarCorrectedSentence: data.result.grammarCorrectedSentence,
          accentGuidance: data.result.accentGuidance,
        };

        setMessages((prev) => [...prev, coachMsg]);
        onCoachListeningChange(false);
        onCoachSpeakingChange(true);
        onUpdateCoachStatus(data.result.coachAnswer);

        // Automatically speak Coach's answer using human voice
        handlePlayMessageVoice(coachMsg);
      }
    } catch (err) {
      console.error("Failed to send question to coach:", err);
      const fallbackMsg: CoachMessage = {
        id: `coach-${Date.now()}`,
        sender: 'coach',
        text: "I'm right here with you! Let's examine your phrasing: ensure your subject matches your verb, and keep your tongue tip relaxed. Feel free to rephrase or try another sentence!",
        timestamp: 'Just now',
        accent: targetAccent,
        mistakes: [],
      };
      setMessages((prev) => [...prev, fallbackMsg]);
      onCoachListeningChange(false);
    } finally {
      setIsAsking(false);
    }
  };

  return (
    <div className={`bg-slate-900/90 rounded-2xl border border-slate-800 shadow-2xl flex flex-col overflow-hidden ${className}`}>
      {/* Q&A Header */}
      <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
            <MessageSquare className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-sm sm:text-base font-bold text-slate-100">
                Ask Coach Dr. Mask Anything
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Grammar & Accent Detective
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Instant answers with human voice speech & proactive mistake alerts
            </p>
          </div>
        </div>

        {/* Accent indicator */}
        <div className="flex items-center space-x-2">
          <button
            id="qa-toggle-accent-btn"
            onClick={() => onAccentChange(targetAccent === 'american' ? 'british' : 'american')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
              targetAccent === 'american'
                ? 'bg-blue-950 text-blue-300 border-blue-800'
                : 'bg-rose-950 text-rose-300 border-rose-800'
            }`}
            title="Click to switch accent focus"
          >
            {targetAccent === 'american' ? '🇺🇸 American (GA)' : '🇬🇧 British (RP)'}
          </button>
        </div>
      </div>

      {/* Suggested Quick Questions */}
      <div className="px-4 py-2 bg-slate-950/40 border-b border-slate-800/80 flex items-center space-x-2 overflow-x-auto text-[11px] scrollbar-none">
        <span className="text-slate-500 font-semibold shrink-0 flex items-center space-x-1">
          <Zap className="w-3 h-3 text-amber-400" />
          <span>Try asking:</span>
        </span>
        {PROMPT_SUGGESTIONS.map((sugg, i) => (
          <button
            key={i}
            id={`suggested-q-${i}`}
            onClick={() => handleSendQuestion(sugg)}
            className="shrink-0 px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-slate-750 text-slate-300 hover:text-cyan-200 border border-slate-700/60 transition-colors"
          >
            {sugg}
          </button>
        ))}
      </div>

      {/* Chat Messages Feed */}
      <div
        ref={chatContainerRef}
        className="p-4 sm:p-5 flex-1 min-h-[320px] max-h-[460px] overflow-y-auto space-y-4 bg-slate-950/20"
      >
        {messages.map((msg) => {
          const isCoach = msg.sender === 'coach';
          const isAudioPlaying = activeAudioMessageId === msg.id;

          return (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex flex-col ${isCoach ? 'items-start' : 'items-end'}`}
            >
              <div
                className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-4 shadow-md ${
                  isCoach
                    ? 'bg-slate-850 border border-slate-700/80 text-slate-100 rounded-tl-sm'
                    : 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-tr-sm'
                }`}
              >
                {/* Header info */}
                <div className="flex items-center justify-between gap-3 mb-1.5 text-[11px] opacity-80">
                  <span className="font-semibold">
                    {isCoach ? 'Coach Dr. Mask' : 'You'}
                  </span>
                  <span>{msg.timestamp}</span>
                </div>

                {/* Main Message Text */}
                <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap">
                  {msg.text}
                </p>

                {/* Grammar Correction Alert Banner */}
                {isCoach && msg.grammarCorrectedSentence && (
                  <div className="mt-3 p-2.5 rounded-xl bg-cyan-950/60 border border-cyan-700/60 text-xs">
                    <span className="font-bold text-cyan-300 block mb-0.5">
                      ✨ Corrected Phrasing:
                    </span>
                    <span className="text-cyan-100 font-medium font-serif italic">
                      "{msg.grammarCorrectedSentence}"
                    </span>
                  </div>
                )}

                {/* Proactive Mistake Prompts (Grammar & Accent Detective) */}
                {isCoach && msg.mistakes && msg.mistakes.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {msg.mistakes.map((mistake, idx) => (
                      <div
                        key={idx}
                        className={`p-2.5 rounded-xl border text-xs space-y-1 ${
                          mistake.severity === 'correction'
                            ? mistake.type === 'grammar'
                              ? 'bg-amber-950/40 border-amber-600/50 text-amber-200'
                              : 'bg-rose-950/40 border-rose-600/50 text-rose-200'
                            : 'bg-emerald-950/40 border-emerald-600/50 text-emerald-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold uppercase tracking-wider text-[10px] flex items-center space-x-1">
                            {mistake.severity === 'correction' ? (
                              <AlertTriangle className="w-3 h-3 text-amber-400" />
                            ) : (
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            )}
                            <span>
                              {mistake.type.toUpperCase()} {mistake.severity === 'correction' ? 'COACH ALERT' : 'CHECK'}
                            </span>
                          </span>

                          {mistake.accentContext && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900/60 border border-slate-700">
                              {mistake.accentContext}
                            </span>
                          )}
                        </div>

                        {mistake.originalPart && mistake.correctedPart && (
                          <div className="flex items-center space-x-2 text-xs font-mono py-0.5">
                            <span className="line-through text-slate-400">
                              {mistake.originalPart}
                            </span>
                            <span>➔</span>
                            <span className="font-bold text-emerald-300">
                              {mistake.correctedPart}
                            </span>
                          </div>
                        )}

                        <p className="text-[11px] leading-snug text-slate-300">
                          {mistake.explanation}
                        </p>

                        {mistake.anatomicalTip && (
                          <div className="pt-1 text-[11px] text-cyan-300 flex items-start space-x-1">
                            <span className="font-semibold shrink-0">👅 Mouth Mechanics:</span>
                            <span>{mistake.anatomicalTip}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Accent Guidance Note */}
                {isCoach && msg.accentGuidance && (
                  <div className="mt-2 text-[11px] text-slate-300 bg-slate-900/60 px-2.5 py-1.5 rounded-lg border border-slate-800">
                    <span className="font-semibold text-cyan-300">Intonation & Flow: </span>
                    {msg.accentGuidance}
                  </div>
                )}

                {/* Human Voice Playback Button for Coach Answers */}
                {isCoach && (
                  <div className="mt-3 pt-2 border-t border-slate-700/60 flex items-center justify-between">
                    <button
                      id={`play-coach-voice-btn-${msg.id}`}
                      onClick={() => handlePlayMessageVoice(msg)}
                      className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        isAudioPlaying
                          ? 'bg-emerald-600 text-white shadow-md animate-pulse'
                          : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700'
                      }`}
                    >
                      {isAudioPlaying ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5" />
                          <span>Stop Voice</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Listen with Human Voice</span>
                        </>
                      )}
                    </button>

                    <span className="text-[10px] text-slate-400">
                      Coach Dr. Mask Voice (
                      {msg.accent === 'british' ? '🇬🇧 RP' : '🇺🇸 GA'})
                    </span>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}

        {isAsking && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start"
          >
            <div className="bg-slate-850 border border-slate-700/80 rounded-2xl rounded-tl-sm p-4 text-xs text-slate-300 flex items-center space-x-3 shadow-md">
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
              <span>
                Coach Dr. Mask is analyzing grammar, accent mechanics, and preparing a human voice response...
              </span>
            </div>
          </motion.div>
        )}
      </div>

      {/* Input & Voice Controls Bar */}
      <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendQuestion();
          }}
          className="flex items-center space-x-2"
        >
          {/* Microphone button to speak question directly */}
          <button
            type="button"
            id="qa-mic-btn"
            onClick={toggleVoiceQuestion}
            title={isVoiceInputActive ? 'Stop listening' : 'Ask question by speaking'}
            className={`p-3 rounded-xl flex items-center justify-center transition-all ${
              isVoiceInputActive
                ? 'bg-rose-600 text-white animate-pulse shadow-lg shadow-rose-600/30'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            {isVoiceInputActive ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          {/* Text input for question */}
          <input
            id="qa-input-field"
            type="text"
            value={inputQuestion}
            onChange={(e) => setInputQuestion(e.target.value)}
            placeholder={
              isVoiceInputActive
                ? 'Listening... Speak your question now'
                : 'Ask Coach Dr. Mask any question or say a sentence to check grammar & accent...'
            }
            className="flex-1 px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/90 text-slate-100 placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
          />

          {/* Send question button */}
          <button
            type="submit"
            id="qa-send-btn"
            disabled={!inputQuestion.trim() || isAsking}
            className={`px-4 py-3 rounded-xl font-bold text-xs sm:text-sm text-white flex items-center space-x-1.5 transition-all shadow-md ${
              !inputQuestion.trim() || isAsking
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-cyan-500/20'
            }`}
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Ask Coach</span>
          </button>
        </form>

        <div className="flex items-center justify-between mt-2 px-1 text-[11px] text-slate-500">
          <span>
            💡 Coach Dr. Mask proactively alerts you if you use non-standard grammar or mispronounce key vowels and consonants.
          </span>
          <span className="hidden md:inline">Voice: Neural Human Speech</span>
        </div>
      </div>
    </div>
  );
};
