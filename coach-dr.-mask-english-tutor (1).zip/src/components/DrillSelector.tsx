import React, { useState } from 'react';
import { PracticeSentence } from '../types';
import { DRILL_SENTENCES } from '../data/curriculum';
import { BookOpen, Sparkles, Plus, Check } from 'lucide-react';

interface DrillSelectorProps {
  selectedSentence: PracticeSentence;
  onSelectSentence: (sentence: PracticeSentence) => void;
  className?: string;
}

export const DrillSelector: React.FC<DrillSelectorProps> = ({
  selectedSentence,
  onSelectSentence,
  className = '',
}) => {
  const [customSentenceText, setCustomSentenceText] = useState('');
  const [isAddingCustom, setIsAddingCustom] = useState(false);

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSentenceText.trim()) return;

    const newDrill: PracticeSentence = {
      id: `custom-${Date.now()}`,
      sentence: customSentenceText.trim(),
      targetFocus: 'Custom Accent Practice Drill',
      americanPhonetic: 'Custom Phonetic Breakdown',
      britishPhonetic: 'Custom Phonetic Breakdown',
      americanIPA: '/custom/',
      britishIPA: '/custom/',
      coachAdvice: 'Practice articulating every consonant cleanly and observe how your tongue tip moves!',
      keyWords: [],
    };

    onSelectSentence(newDrill);
    setCustomSentenceText('');
    setIsAddingCustom(false);
  };

  return (
    <div className={`bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-lg ${className}`}>
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-bold text-slate-100">Practice Sentences & Accent Drills</h3>
        </div>
        <button
          onClick={() => setIsAddingCustom(!isAddingCustom)}
          className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center space-x-1"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isAddingCustom ? 'Cancel' : 'Custom Sentence'}</span>
        </button>
      </div>

      {isAddingCustom && (
        <form onSubmit={handleAddCustom} className="my-3 flex gap-2">
          <input
            type="text"
            value={customSentenceText}
            onChange={(e) => setCustomSentenceText(e.target.value)}
            placeholder="Type any sentence to practice (e.g. 'Better late than never')..."
            className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
          <button
            type="submit"
            className="px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
          >
            Add
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        {DRILL_SENTENCES.map((drill) => {
          const isSelected = selectedSentence.id === drill.id;
          return (
            <button
              key={drill.id}
              onClick={() => onSelectSentence(drill)}
              className={`text-left p-3.5 rounded-xl border transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-slate-800/90 border-cyan-500/60 shadow-md ring-1 ring-cyan-500/30'
                  : 'bg-slate-950/60 border-slate-800 hover:bg-slate-900 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-[11px] mb-1">
                  <span className="font-semibold text-cyan-400">{drill.targetFocus}</span>
                  {isSelected && (
                    <span className="flex items-center space-x-1 text-emerald-400 font-bold">
                      <Check className="w-3.5 h-3.5" />
                      <span>Active</span>
                    </span>
                  )}
                </div>
                <p className="text-xs font-semibold text-slate-200">
                  "{drill.sentence}"
                </p>
              </div>
              <span className="text-[10px] text-slate-400 mt-2 line-clamp-1">
                {drill.coachAdvice}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
