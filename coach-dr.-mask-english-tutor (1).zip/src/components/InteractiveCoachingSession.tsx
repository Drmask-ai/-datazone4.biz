import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Mic,
  MicOff,
  Send,
  Sparkles,
  Volume2,
  Award,
  RefreshCw,
  Sliders,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  ChevronDown,
  VolumeX,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { AccentType, CoachEvaluation, PracticeSentence } from '../types';
import { FEATURED_SENTENCE } from '../data/curriculum';
import { speakWithCoach, stopCoachSpeech } from '../utils/audioSpeech';

interface InteractiveCoachingSessionProps {
  currentSentence?: PracticeSentence;
  targetAccent: AccentType;
  onAccentChange: (accent: AccentType) => void;
  onCoachSpeakingChange: (isSpeaking: boolean) => void;
  onCoachListeningChange: (isListening: boolean) => void;
  onUpdateCoachStatus: (text: string) => void;
  className?: string;
}

export const InteractiveCoachingSession: React.FC<InteractiveCoachingSessionProps> = ({
  currentSentence = FEATURED_SENTENCE,
  targetAccent,
  onAccentChange,
  onCoachSpeakingChange,
  onCoachListeningChange,
  onUpdateCoachStatus,
  className = '',
}) => {
  const [userPhonetic, setUserPhonetic] = useState<string>('');
  const [feeling, setFeeling] = useState<string>('The R sounds felt tricky to roll back');
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [audioBlobUrl, setAudioBlobUrl] = useState<string | null>(null);
  const [speechTranscript, setSpeechTranscript] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [evaluation, setEvaluation] = useState<CoachEvaluation | null>(null);
  const [selectedWordDetail, setSelectedWordDetail] = useState<string | null>(null);

  // Audio recording references
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const speechRecognitionRef = useRef<any>(null);

  // Suggested feeling presets for rapid interaction
  const feelingPresets = [
    "The 'R' sound in park felt unnatural to roll back",
    "Flapping the 'T' in water felt smooth and light",
    "Dropping the 'R' in park made the vowel feel very long",
    "The True 'T' in bottle felt crisp and clean",
    "Connected speech flowed well between bottle and of",
  ];

  // Quick phonetic templates based on selected accent
  const handleInsertTemplate = (type: 'american' | 'british') => {
    if (type === 'american') {
      setUserPhonetic("Ai'd lahyk uh bah-dl uhv wah-der af-ter my mor-ning pahrk run.");
    } else {
      setUserPhonetic("Ahy'd layk a bot-uhl ov waw-tuh ahf-tuh my maw-ning pahk run.");
    }
  };

  // Listen to the target sentence in selected accent
  const handleListenToSentence = (accent: AccentType) => {
    onCoachSpeakingChange(true);
    onUpdateCoachStatus(`Demonstrating in ${accent === 'british' ? 'British RP' : 'General American'}: "${currentSentence.sentence}"`);
    speakWithCoach(currentSentence.sentence, accent, {
      rate: 0.9,
      onEnd: () => {
        onCoachSpeakingChange(false);
      },
    });
  };

  // Microphone recording
  const startRecording = async () => {
    try {
      audioChunksRef.current = [];
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setAudioBlobUrl(url);
        stream.getTracks().forEach((track) => track.stop());
      };

      recorder.start();
      setIsRecording(true);
      onCoachListeningChange(true);
      onUpdateCoachStatus("Listening to your voice! Speak clearly into your microphone...");

      // Web Speech API for live transcription
      if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
        const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        const recognition = new SpeechRec();
        recognition.lang = targetAccent === 'british' ? 'en-GB' : 'en-US';
        recognition.continuous = false;
        recognition.interimResults = true;

        recognition.onresult = (event: any) => {
          const current = event.resultIndex;
          const transcript = event.results[current][0].transcript;
          setSpeechTranscript(transcript);
        };

        recognition.onerror = (event: any) => {
          console.warn("Speech recognition error:", event.error);
        };

        recognition.start();
        speechRecognitionRef.current = recognition;
      }
    } catch (err) {
      console.error("Microphone access denied or error:", err);
      alert("Microphone permission was not granted. You can still type your phonetic pronunciation!");
      setIsRecording(false);
      onCoachListeningChange(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      onCoachListeningChange(false);
      onUpdateCoachStatus("Recording captured! Review your audio or click 'Submit to Coach Dr. Mask'.");
    }
    if (speechRecognitionRef.current) {
      speechRecognitionRef.current.stop();
    }
  };

  // Submit response to Coach Dr. Mask
  const handleSubmitToCoach = async () => {
    setIsAnalyzing(true);
    onCoachListeningChange(true);
    onUpdateCoachStatus("Analyzing your phonetics, tongue positioning, and accent mechanics...");

    try {
      const response = await fetch('/api/coach/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sentence: currentSentence.sentence,
          userPhonetic: userPhonetic.trim() || currentSentence.americanPhonetic,
          targetAccent,
          feeling,
          recognizedTranscript: speechTranscript,
        }),
      });

      const data = await response.json();
      if (data.success && data.analysis) {
        setEvaluation(data.analysis);
        onCoachListeningChange(false);
        onUpdateCoachStatus(data.analysis.coachGreeting);

        // Celebrate good scores with confetti
        if (data.analysis.score >= 85) {
          confetti({
            particleCount: 80,
            spread: 60,
            origin: { y: 0.6 },
          });
        }
      }
    } catch (err) {
      console.error("Analysis error:", err);
      onCoachListeningChange(false);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Target Sentence Hero Banner */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl relative overflow-hidden">
        <div className="flex items-center justify-between gap-3 mb-2">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              Live Session Challenge
            </span>
            <span className="text-xs text-slate-400 font-medium">
              Target Focus: {currentSentence.targetFocus}
            </span>
          </div>

          {/* Demonstration audio buttons */}
          <div className="flex items-center space-x-2">
            <button
              id="listen-target-us-btn"
              onClick={() => handleListenToSentence('american')}
              className="px-2.5 py-1 rounded-lg bg-blue-900/40 text-blue-300 border border-blue-700/50 hover:bg-blue-800/40 text-xs font-semibold flex items-center space-x-1.5 transition-colors"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Demo US</span>
            </button>
            <button
              id="listen-target-uk-btn"
              onClick={() => handleListenToSentence('british')}
              className="px-2.5 py-1 rounded-lg bg-rose-900/40 text-rose-300 border border-rose-700/50 hover:bg-rose-800/40 text-xs font-semibold flex items-center space-x-1.5 transition-colors"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Demo UK</span>
            </button>
          </div>
        </div>

        {/* The Sentence */}
        <h1 className="text-xl sm:text-2xl font-bold text-slate-100 my-3 tracking-tight font-serif">
          "{currentSentence.sentence}"
        </h1>

        {/* Phonetic Pronunciation comparison preview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 pt-3 border-t border-slate-800/80">
          <div className={`p-3 rounded-xl border transition-all ${
            targetAccent === 'american'
              ? 'bg-blue-950/40 border-blue-600/50 shadow-sm'
              : 'bg-slate-950/40 border-slate-800 opacity-75'
          }`}>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-bold text-blue-400">🇺🇸 General American (GA)</span>
              <span className="text-[10px] font-mono text-slate-400">{currentSentence.americanIPA}</span>
            </div>
            <p className="text-xs font-mono text-slate-200">
              {currentSentence.americanPhonetic}
            </p>
          </div>

          <div className={`p-3 rounded-xl border transition-all ${
            targetAccent === 'british'
              ? 'bg-rose-950/40 border-rose-600/50 shadow-sm'
              : 'bg-slate-950/40 border-slate-800 opacity-75'
          }`}>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-bold text-rose-400">🇬🇧 British (RP)</span>
              <span className="text-[10px] font-mono text-slate-400">{currentSentence.britishIPA}</span>
            </div>
            <p className="text-xs font-mono text-slate-200">
              {currentSentence.britishPhonetic}
            </p>
          </div>
        </div>

        {/* Word-by-word interactive acoustic cards */}
        <div className="mt-4 pt-3 border-t border-slate-800/80">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            Key Articulation Touchpoints (Click any word to inspect):
          </span>
          <div className="flex flex-wrap gap-2">
            {currentSentence.keyWords.map((item) => (
              <button
                key={item.word}
                id={`keyword-${item.word}`}
                onClick={() => setSelectedWordDetail(selectedWordDetail === item.word ? null : item.word)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all flex items-center space-x-1.5 ${
                  selectedWordDetail === item.word
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-500 shadow-md'
                    : 'bg-slate-800/60 text-slate-300 border-slate-700 hover:bg-slate-750'
                }`}
              >
                <span className="font-bold">{item.word}</span>
                <span className="text-[10px] text-slate-400">
                  {targetAccent === 'american' ? item.american.split(' ')[0] : item.british.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>

          {selectedWordDetail && (
            <div className="mt-3 p-3 rounded-xl bg-slate-950/90 border border-cyan-500/40 text-xs text-slate-200">
              {(() => {
                const item = currentSentence.keyWords.find((k) => k.word === selectedWordDetail);
                if (!item) return null;
                return (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between font-semibold text-cyan-300">
                      <span>Word breakdown: "{item.word}"</span>
                      <button
                        onClick={() => speakWithCoach(item.word, targetAccent)}
                        className="flex items-center space-x-1 text-slate-400 hover:text-white"
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>Hear</span>
                      </button>
                    </div>
                    <p className="text-slate-300">{item.rule}</p>
                    <div className="flex gap-4 pt-1 text-[11px] font-mono text-slate-400">
                      <span>US: <strong className="text-blue-300">{item.american}</strong></span>
                      <span>UK: <strong className="text-rose-300">{item.british}</strong></span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      </div>

      {/* User Speaking & Reply Studio Card */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
              <span>Your Turn to Speak!</span>
              <Sparkles className="w-4 h-4 text-cyan-400" />
            </h2>
            <p className="text-xs text-slate-400">
              Submit your phonetic transcription, voice recording, and feel of the sentence.
            </p>
          </div>

          {/* Accent Selection */}
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400 font-medium">Focus Accent:</span>
            <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800">
              <button
                id="select-us-accent-btn"
                onClick={() => onAccentChange('american')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  targetAccent === 'american'
                    ? 'bg-blue-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                🇺🇸 American
              </button>
              <button
                id="select-uk-accent-btn"
                onClick={() => onAccentChange('british')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  targetAccent === 'british'
                    ? 'bg-rose-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                🇬🇧 British
              </button>
            </div>
          </div>
        </div>

        {/* Audio Recording Section (Voice Microphone) */}
        <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <button
              id="toggle-mic-btn"
              onClick={isRecording ? stopRecording : startRecording}
              className={`p-3.5 rounded-2xl flex items-center justify-center transition-all shadow-lg ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse shadow-rose-600/30'
                  : 'bg-cyan-600 text-white hover:bg-cyan-500 shadow-cyan-600/30'
              }`}
            >
              {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-200">
                  {isRecording ? 'Recording your pronunciation...' : 'Optional: Record Your Voice'}
                </span>
                {isRecording && (
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500" />
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                {isRecording
                  ? 'Say: "I\'d like a bottle of water after my morning park run"'
                  : 'Click mic to speak aloud into your browser microphone'}
              </p>
            </div>
          </div>

          {/* Audio Player for recorded voice */}
          {audioBlobUrl && !isRecording && (
            <div className="flex items-center space-x-2">
              <audio controls src={audioBlobUrl} className="h-8 max-w-[200px]" />
            </div>
          )}

          {speechTranscript && (
            <div className="text-[11px] bg-slate-900 px-3 py-1 rounded-lg border border-slate-800 text-cyan-300">
              Heard: "{speechTranscript}"
            </div>
          )}
        </div>

        {/* 1. Phonetic Spelling Input */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-slate-200 flex items-center space-x-1.5">
              <span>1. How you think you pronounced it (Phonetic spelling)</span>
            </label>
            <div className="flex items-center space-x-1.5">
              <span className="text-[11px] text-slate-400">Quick template:</span>
              <button
                id="template-us-btn"
                onClick={() => handleInsertTemplate('american')}
                className="text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-950 text-blue-300 hover:bg-blue-900 border border-blue-800/60"
              >
                GA Template
              </button>
              <button
                id="template-uk-btn"
                onClick={() => handleInsertTemplate('british')}
                className="text-[10px] font-semibold px-2 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-900 border border-rose-800/60"
              >
                RP Template
              </button>
            </div>
          </div>
          <input
            id="user-phonetic-input"
            type="text"
            value={userPhonetic}
            onChange={(e) => setUserPhonetic(e.target.value)}
            placeholder={
              targetAccent === 'american'
                ? "e.g., Ai'd lahyk uh bah-dl uhv wah-der af-ter my mor-ning pahrk run."
                : "e.g., Ahy'd layk a bot-uhl ov waw-tuh ahf-tuh my maw-ning pahk run."
            }
            className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700/80 text-slate-100 placeholder-slate-500 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
          />
        </div>

        {/* 2. How Did That Sentence Feel For You? */}
        <div>
          <label className="text-xs font-bold text-slate-200 block mb-1.5">
            2. How did that sentence feel for you? (Mouth tension, tongue placement, rhythm)
          </label>
          <input
            id="user-feeling-input"
            type="text"
            value={feeling}
            onChange={(e) => setFeeling(e.target.value)}
            placeholder="e.g., The 'R' in park felt hard to roll back, or the flap T felt easy..."
            className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700/80 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
          />

          {/* Feeling preset chips */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {feelingPresets.map((preset, idx) => (
              <button
                key={idx}
                id={`preset-feeling-${idx}`}
                onClick={() => setFeeling(preset)}
                className="px-2.5 py-1 rounded-lg text-[10px] bg-slate-800/70 text-slate-300 hover:bg-slate-750 hover:text-cyan-300 border border-slate-700/60 transition-colors"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Submit to Coach Dr. Mask Button */}
        <div className="pt-2">
          <button
            id="submit-to-coach-btn"
            onClick={handleSubmitToCoach}
            disabled={isAnalyzing}
            className={`w-full py-3.5 rounded-xl font-bold text-sm text-white flex items-center justify-center space-x-2 transition-all shadow-lg ${
              isAnalyzing
                ? 'bg-slate-700 cursor-not-allowed'
                : 'bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 shadow-teal-500/20'
            }`}
          >
            {isAnalyzing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Coach Dr. Mask is analyzing your mechanics...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Submit to Coach Dr. Mask for Feedback</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Comprehensive Coach Dr. Mask Feedback Breakdown Card */}
      <AnimatePresence>
        {evaluation && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="bg-slate-900/90 rounded-2xl border border-emerald-500/40 p-6 shadow-2xl space-y-5 relative overflow-hidden"
          >
            {/* Top Score Banner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  {evaluation.score}%
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-base font-bold text-slate-100">
                      Coach Dr. Mask's Accent Assessment
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {evaluation.ratingLabel}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Target Accent: {evaluation.accentAnalyzed} English
                  </p>
                </div>
              </div>

              {/* Read Feedback Aloud Button */}
              <button
                id="coach-read-feedback-btn"
                onClick={() => {
                  onCoachSpeakingChange(true);
                  speakWithCoach(
                    `${evaluation.coachGreeting} For the R sound: ${evaluation.rSoundFeedback.observation} For the T sound: ${evaluation.tSoundFeedback.observation}`,
                    targetAccent,
                    {
                      rate: 0.95,
                      onEnd: () => onCoachSpeakingChange(false),
                    }
                  );
                }}
                className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-750 text-xs font-semibold border border-slate-700 transition-colors"
              >
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>Hear Coach Breakdown</span>
              </button>
            </div>

            {/* Coach Greeting & Motivational Observation */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
              <p className="text-xs leading-relaxed text-slate-200">
                "{evaluation.coachGreeting}"
              </p>
            </div>

            {/* Core Sound Pillars: Rhoticity & Flap T Mechanics */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* R Sound Pillar */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">
                    The 'R' Sound (Rhoticity)
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      evaluation.rSoundFeedback.status === 'excellent'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {evaluation.rSoundFeedback.status.toUpperCase().replace('_', ' ')}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {evaluation.rSoundFeedback.observation}
                </p>
                <div className="pt-2 border-t border-slate-800/80 text-[11px] text-cyan-300">
                  <strong>Tongue Positioning: </strong>
                  {evaluation.rSoundFeedback.anatomicalGuidance}
                </div>
              </div>

              {/* T Sound Pillar */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">
                    The 'T' Sound (Flap vs True T)
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      evaluation.tSoundFeedback.status === 'excellent'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {evaluation.tSoundFeedback.status.toUpperCase().replace('_', ' ')}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {evaluation.tSoundFeedback.observation}
                </p>
                <div className="pt-2 border-t border-slate-800/80 text-[11px] text-cyan-300">
                  <strong>Alveolar Tap / Seal: </strong>
                  {evaluation.tSoundFeedback.anatomicalGuidance}
                </div>
              </div>
            </div>

            {/* Vowels and Rhythm */}
            {evaluation.vowelAndRhythmFeedback && (
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300">
                <strong className="text-slate-200">Vowel Quality & Connected Rhythm: </strong>
                {evaluation.vowelAndRhythmFeedback}
              </div>
            )}

            {/* Word by word breakdown table */}
            {evaluation.wordByWordBreakdown && evaluation.wordByWordBreakdown.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-200 block">
                  Word-by-Word Anatomical Placement:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {evaluation.wordByWordBreakdown.map((item, i) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold text-cyan-400">
                        <span>{item.word}</span>
                        <span className="font-mono text-[10px] text-slate-400">{item.ipa}</span>
                      </div>
                      <div className="text-[11px] font-mono text-emerald-400">
                        {item.targetPhonetic}
                      </div>
                      <div className="text-[10px] text-slate-300">
                        <strong>Tongue: </strong> {item.tongueTip}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        <strong>Lips: </strong> {item.lipShape}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Next Drill Tip */}
            <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-start space-x-2.5">
              <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div className="text-xs">
                <strong className="text-cyan-200">Coach Dr. Mask's Quick Drill Tip: </strong>
                <span className="text-slate-200">{evaluation.nextDrillTip}</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
