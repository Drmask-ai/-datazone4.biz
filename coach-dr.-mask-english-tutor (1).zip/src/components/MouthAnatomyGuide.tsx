import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Volume2, ChevronRight, CheckCircle2, Info, ArrowRight } from 'lucide-react';
import { AccentType } from '../types';
import { SOUND_COMPARISONS } from '../data/curriculum';
import { speakWithCoach } from '../utils/audioSpeech';

interface MouthAnatomyGuideProps {
  currentAccent: AccentType;
  onAccentChange: (accent: AccentType) => void;
  className?: string;
}

export const MouthAnatomyGuide: React.FC<MouthAnatomyGuideProps> = ({
  currentAccent,
  onAccentChange,
  className = '',
}) => {
  const [selectedSoundIndex, setSelectedSoundIndex] = useState<number>(0);
  const currentSound = SOUND_COMPARISONS[selectedSoundIndex];

  const handlePlaySoundDemo = (accent: AccentType, word: string) => {
    speakWithCoach(word, accent, {
      rate: 0.85,
    });
  };

  return (
    <div className={`bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl ${className}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 uppercase tracking-wider">
              Anatomical Vocal Tract Guide
            </span>
            <span className="text-xs text-slate-400">• Step-by-step Lip & Tongue Guides</span>
          </div>
          <h2 className="text-lg font-bold text-slate-100 mt-1">
            Visual Mouth & Tongue Placement
          </h2>
        </div>

        {/* Accent Switcher Tabs */}
        <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 shrink-0">
          <button
            id="tab-accent-american"
            onClick={() => onAccentChange('american')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              currentAccent === 'american'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🇺🇸 General American (GA)
          </button>
          <button
            id="tab-accent-british"
            onClick={() => onAccentChange('british')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              currentAccent === 'british'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🇬🇧 British (RP)
          </button>
        </div>
      </div>

      {/* Sound Comparison Selector Pills */}
      <div className="flex flex-wrap gap-2 my-4">
        {SOUND_COMPARISONS.map((sound, idx) => (
          <button
            key={sound.soundName}
            id={`sound-tab-${idx}`}
            onClick={() => setSelectedSoundIndex(idx)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all flex items-center space-x-2 border ${
              selectedSoundIndex === idx
                ? 'bg-gradient-to-r from-slate-800 to-slate-750 text-cyan-300 border-cyan-500/50 shadow-md ring-1 ring-cyan-500/30'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200 hover:border-slate-700'
            }`}
          >
            <span className="font-semibold">{sound.soundName}</span>
          </button>
        ))}
      </div>

      {/* Main Visualizer Stage: Cross-Section Vocal Tract & Frontal Lip View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 my-4">
        {/* Left: Sagittal Anatomical Cross-Section Graphic */}
        <div className="lg:col-span-6 bg-slate-950/80 rounded-xl p-4 border border-slate-800 flex flex-col items-center">
          <div className="w-full flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider font-semibold">
              Sagittal Cross-Section (Lateral View)
            </span>
            <span className="text-[11px] text-slate-400 font-medium">
              {currentAccent === 'american' ? 'American Articulation' : 'British Articulation'}
            </span>
          </div>

          <div className="relative w-full max-w-[280px] h-[220px] flex justify-center items-center">
            <svg viewBox="0 0 300 240" className="w-full h-full filter drop-shadow-md">
              <defs>
                <linearGradient id="tongueGradient" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#f43f5e" />
                  <stop offset="100%" stopColor="#be123c" />
                </linearGradient>
                <linearGradient id="palateGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#fdba74" />
                  <stop offset="100%" stopColor="#ea580c" />
                </linearGradient>
              </defs>

              {/* Hard & Soft Palate, Upper Lip & Tooth */}
              <path
                d="M 60 90 Q 75 90 85 92 L 95 105 L 105 105 L 105 85 Q 150 82 200 110 Q 230 130 240 190"
                stroke="#64748b"
                strokeWidth="4"
                fill="none"
              />
              {/* Alveolar Ridge & Upper Teeth */}
              <rect x="94" y="98" width="10" height="15" rx="2" fill="#ffffff" stroke="#94a3b8" strokeWidth="1" />
              <text x="100" y="80" fill="#94a3b8" fontSize="9" textAnchor="middle">
                Alveolar Ridge
              </text>
              <line x1="100" y1="84" x2="100" y2="96" stroke="#94a3b8" strokeWidth="1" strokeDasharray="2,2" />

              {/* Hard Palate Label */}
              <text x="160" y="75" fill="#94a3b8" fontSize="9" textAnchor="middle">
                Hard Palate
              </text>
              <line x1="160" y1="78" x2="160" y2="88" stroke="#94a3b8" strokeWidth="1" strokeDasharray="2,2" />

              {/* Lower Lip & Lower Teeth */}
              <rect x="94" y="145" width="10" height="15" rx="2" fill="#ffffff" stroke="#94a3b8" strokeWidth="1" />
              <path d="M 60 160 Q 75 160 85 158 L 95 145" stroke="#64748b" strokeWidth="4" fill="none" />

              {/* Pharynx & Airway Back Wall */}
              <path d="M 240 190 L 240 230" stroke="#475569" strokeWidth="4" />
              <path d="M 170 230 Q 175 210 170 190" stroke="#475569" strokeWidth="3" fill="none" />

              {/* Dynamic Tongue Positioning depending on Sound & Accent */}
              {selectedSoundIndex === 0 ? (
                // 'R' SOUND
                currentAccent === 'american' ? (
                  // American Rhotic R: Retroflex / Bunched tongue curled back, NOT touching roof!
                  <g>
                    <path
                      d="M 105 155 Q 120 152 145 142 Q 170 115 155 105 Q 140 102 140 120 Q 140 160 180 190 Q 165 210 130 200 Z"
                      fill="url(#tongueGradient)"
                      stroke="#fb7185"
                      strokeWidth="2.5"
                    />
                    {/* Airflow arrow curving under tongue */}
                    <path
                      d="M 210 170 Q 175 125 120 112 L 80 112"
                      stroke="#38bdf8"
                      strokeWidth="3"
                      strokeDasharray="4,4"
                      fill="none"
                    />
                    <text x="155" y="96" fill="#38bdf8" fontSize="10" fontWeight="bold" textAnchor="middle">
                      Curled back (Never touches!)
                    </text>
                  </g>
                ) : (
                  // British Non-rhotic R: Tongue rests low and relaxed, wide open airway
                  <g>
                    <path
                      d="M 105 155 Q 125 155 150 150 Q 180 145 190 170 Q 175 200 130 195 Z"
                      fill="url(#tongueGradient)"
                      stroke="#fb7185"
                      strokeWidth="2.5"
                    />
                    {/* Smooth open airflow */}
                    <path
                      d="M 215 150 Q 175 110 80 115"
                      stroke="#f59e0b"
                      strokeWidth="3"
                      strokeDasharray="4,4"
                      fill="none"
                    />
                    <text x="150" y="135" fill="#f59e0b" fontSize="10" fontWeight="bold" textAnchor="middle">
                      Low & Relaxed (Schwa /ə/)
                    </text>
                  </g>
                )
              ) : selectedSoundIndex === 1 ? (
                // 'T' SOUND
                currentAccent === 'american' ? (
                  // American Flap T: Quick tap bounce against alveolar ridge
                  <g>
                    <path
                      d="M 105 155 Q 115 140 102 114 Q 106 102 100 100 Q 112 116 128 135 Q 155 160 175 190 Q 155 205 125 195 Z"
                      fill="url(#tongueGradient)"
                      stroke="#fb7185"
                      strokeWidth="2.5"
                    />
                    {/* Continuous vibration wave */}
                    <path
                      d="M 200 180 Q 150 140 80 120"
                      stroke="#38bdf8"
                      strokeWidth="2.5"
                      strokeDasharray="2,2"
                      fill="none"
                    />
                    <text x="85" y="68" fill="#38bdf8" fontSize="9.5" fontWeight="bold">
                      Light Tap Bounce [ɾ]
                    </text>
                    <circle cx="100" cy="100" r="4" fill="#38bdf8" />
                  </g>
                ) : (
                  // British True T: Firm airtight seal building pressure, then sharp release
                  <g>
                    <path
                      d="M 105 155 Q 112 135 104 108 Q 100 98 100 98 L 105 106 Q 120 125 145 150 Q 165 180 175 190 Q 155 205 125 195 Z"
                      fill="url(#tongueGradient)"
                      stroke="#fb7185"
                      strokeWidth="2.5"
                    />
                    {/* Pressure burst icon */}
                    <circle cx="100" cy="98" r="5" fill="#ef4444" />
                    <text x="75" y="68" fill="#ef4444" fontSize="9.5" fontWeight="bold">
                      Firm Seal & Burst [tʰ]
                    </text>
                  </g>
                )
              ) : (
                // Vowels ('O' Sound)
                currentAccent === 'american' ? (
                  <g>
                    {/* American open unrounded /ɑ/ */}
                    <path
                      d="M 105 160 Q 130 165 160 155 Q 185 170 175 195 Q 155 205 125 195 Z"
                      fill="url(#tongueGradient)"
                      stroke="#fb7185"
                      strokeWidth="2.5"
                    />
                    <text x="145" y="130" fill="#38bdf8" fontSize="10" fontWeight="bold">
                      Open Back /ɑː/ (bah-dl)
                    </text>
                  </g>
                ) : (
                  <g>
                    {/* British rounded /ɒ/ */}
                    <path
                      d="M 105 155 Q 135 150 165 140 Q 185 165 175 195 Q 155 205 125 195 Z"
                      fill="url(#tongueGradient)"
                      stroke="#fb7185"
                      strokeWidth="2.5"
                    />
                    <text x="145" y="125" fill="#f59e0b" fontSize="10" fontWeight="bold">
                      Rounded Back /ɒ/ (bot-uhl)
                    </text>
                  </g>
                )
              )}
            </svg>
          </div>

          <div className="w-full mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
              <span>Tongue Body & Tip</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block" />
              <span>Airflow Direction</span>
            </span>
          </div>
        </div>

        {/* Right: Anatomical Rules & Pronunciation Breakdown */}
        <div className="lg:col-span-6 flex flex-col justify-between space-y-4">
          {/* Active Accent Detailed Specs */}
          <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <span className="text-base font-bold text-slate-100">
                  {currentAccent === 'american'
                    ? currentSound.american.title
                    : currentSound.british.title}
                </span>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-slate-800 text-cyan-300 font-semibold">
                  {currentAccent === 'american' ? currentSound.american.ipa : currentSound.british.ipa}
                </span>
              </div>

              <button
                id="listen-demonstration-sound-btn"
                onClick={() =>
                  handlePlaySoundDemo(
                    currentAccent,
                    currentAccent === 'american'
                      ? currentSound.american.example
                      : currentSound.british.example
                  )
                }
                className="flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-cyan-600/20 text-cyan-300 hover:bg-cyan-600/30 text-xs font-semibold transition-colors border border-cyan-500/30"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Hear Sound</span>
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              {currentAccent === 'american'
                ? currentSound.american.description
                : currentSound.british.description}
            </p>

            {/* Checklist of precise physical movements */}
            <div className="space-y-2.5 pt-2 border-t border-slate-800/80">
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-semibold text-slate-200">Tongue Mechanic: </span>
                  <span className="text-slate-400">
                    {currentAccent === 'american'
                      ? currentSound.american.tongueAction
                      : currentSound.british.tongueAction}
                  </span>
                </div>
              </div>

              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-semibold text-slate-200">Lip & Jaw Geometry: </span>
                  <span className="text-slate-400">
                    {currentAccent === 'american'
                      ? currentSound.american.lipAction
                      : currentSound.british.lipAction}
                  </span>
                </div>
              </div>

              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-semibold text-slate-200">Airflow & Acoustic Pressure: </span>
                  <span className="text-slate-400">
                    {currentAccent === 'american'
                      ? currentSound.american.airflow
                      : currentSound.british.airflow}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Example Words with Audio */}
          <div className="bg-slate-800/40 rounded-xl p-3.5 border border-slate-700/60">
            <span className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider block mb-2">
              Practice Examples for this Sound:
            </span>
            <div className="flex flex-wrap gap-2">
              {(currentAccent === 'american' ? currentSound.american.example : currentSound.british.example)
                .split(',')
                .map((word) => {
                  const clean = word.trim();
                  return (
                    <button
                      key={clean}
                      onClick={() => handlePlaySoundDemo(currentAccent, clean)}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 text-slate-200 hover:bg-slate-750 hover:text-cyan-300 text-xs font-medium border border-slate-700 flex items-center space-x-1.5 transition-colors shadow-sm"
                    >
                      <Volume2 className="w-3 h-3 text-cyan-400" />
                      <span>{clean}</span>
                    </button>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
