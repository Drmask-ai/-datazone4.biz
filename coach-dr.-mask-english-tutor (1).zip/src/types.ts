export type AccentType = 'american' | 'british';

export type VisemeType = 'neutral' | 'smile' | 'open_A' | 'open_O' | 'rounded_W' | 'tongue_T' | 'bunched_R' | 'wide_E';

export interface SoundComparison {
  soundName: string;
  category: 'R-Rhoticity' | 'T-Sound' | 'Vowels' | 'Connected-Speech';
  american: {
    title: string;
    description: string;
    example: string;
    phonetic: string;
    ipa: string;
    tongueAction: string;
    lipAction: string;
    airflow: string;
  };
  british: {
    title: string;
    description: string;
    example: string;
    phonetic: string;
    ipa: string;
    tongueAction: string;
    lipAction: string;
    airflow: string;
  };
}

export interface WordBreakdownItem {
  word: string;
  targetPhonetic: string;
  ipa: string;
  tongueTip: string;
  lipShape: string;
}

export interface CoachEvaluation {
  coachGreeting: string;
  score: number;
  ratingLabel: string;
  accentAnalyzed: string;
  rSoundFeedback: {
    status: 'correct' | 'needs_adjustment' | 'excellent';
    observation: string;
    anatomicalGuidance: string;
  };
  tSoundFeedback: {
    status: 'correct' | 'needs_adjustment' | 'excellent';
    observation: string;
    anatomicalGuidance: string;
  };
  vowelAndRhythmFeedback: string;
  wordByWordBreakdown: WordBreakdownItem[];
  nextDrillTip: string;
}

export interface PracticeSentence {
  id: string;
  sentence: string;
  targetFocus: string;
  americanPhonetic: string;
  britishPhonetic: string;
  americanIPA: string;
  britishIPA: string;
  coachAdvice: string;
  keyWords: {
    word: string;
    american: string;
    british: string;
    rule: string;
  }[];
}

export interface MistakeAlert {
  type: 'grammar' | 'accent' | 'vocabulary' | 'pronunciation';
  severity: 'correction' | 'suggestion' | 'praise';
  originalPart?: string;
  correctedPart?: string;
  explanation: string;
  anatomicalTip?: string;
  accentContext?: 'American' | 'British' | 'Universal';
}

export interface CoachMessage {
  id: string;
  sender: 'user' | 'coach';
  text: string;
  timestamp: string;
  audioBase64?: string; // Neural human voice if generated
  audioMimeType?: string;
  accent?: AccentType;
  mistakes?: MistakeAlert[];
  grammarCorrectedSentence?: string;
  accentGuidance?: string;
  isAudioPlaying?: boolean;
}

