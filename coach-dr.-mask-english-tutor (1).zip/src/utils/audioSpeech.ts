import { VisemeType, AccentType } from '../types';

let currentUtterance: SpeechSynthesisUtterance | null = null;
let currentAudioElement: HTMLAudioElement | null = null;
let currentAudioContext: AudioContext | null = null;
let visemeInterval: NodeJS.Timeout | null = null;

// Cache for generated human voice audio blobs to make repeat queries instantaneous
const audioVoiceCache = new Map<string, string>();

export function getAvailableVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      resolve([]);
      return;
    }
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      resolve(voices);
      return;
    }
    window.speechSynthesis.onvoiceschanged = () => {
      resolve(window.speechSynthesis.getVoices());
    };
    // Fallback if event doesn't fire
    setTimeout(() => {
      resolve(window.speechSynthesis.getVoices());
    }, 500);
  });
}

/**
 * Stop any ongoing coach speech (both HTML5 Audio and SpeechSynthesis)
 */
export function stopCoachSpeech() {
  if (currentAudioElement) {
    try {
      currentAudioElement.pause();
      currentAudioElement.currentTime = 0;
    } catch {
      // Ignore
    }
    currentAudioElement = null;
  }

  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // Ignore
    }
  }

  if (visemeInterval) {
    clearInterval(visemeInterval);
    visemeInterval = null;
  }
  currentUtterance = null;
}

/**
 * Speak with Coach Dr. Mask using natural human voice.
 * Prioritizes Gemini Neural Voice TTS; seamlessly falls back to high-fidelity
 * natural browser human voice synthesis if offline or API key is not configured.
 */
export async function speakWithCoach(
  text: string,
  accent: AccentType,
  options?: {
    rate?: number;
    pitch?: number;
    preferBrowserVoice?: boolean;
    onViseme?: (v: VisemeType) => void;
    onStart?: () => void;
    onEnd?: () => void;
  }
): Promise<boolean> {
  stopCoachSpeech();

  // Viseme cycle sequence for realistic mouth motion
  const visemeSequence: VisemeType[] = [
    'open_A',
    'rounded_W',
    'open_O',
    'tongue_T',
    'bunched_R',
    'wide_E',
    'smile',
    'open_A',
    'tongue_T',
  ];
  let vIndex = 0;

  // 1. Check audio cache first
  const cacheKey = `${accent}:${text.trim().slice(0, 150)}`;
  if (!options?.preferBrowserVoice && audioVoiceCache.has(cacheKey)) {
    const cachedUrl = audioVoiceCache.get(cacheKey)!;
    return playAudioBlob(cachedUrl, visemeSequence, options);
  }

  // 2. Try Gemini Neural Human Voice via server /api/coach/tts
  if (!options?.preferBrowserVoice) {
    try {
      const res = await fetch('/api/coach/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, accent }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.audioBase64) {
          const binary = atob(data.audioBase64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          const blob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
          const blobUrl = URL.createObjectURL(blob);
          audioVoiceCache.set(cacheKey, blobUrl);

          return playAudioBlob(blobUrl, visemeSequence, options);
        }
      }
    } catch (e) {
      console.warn('Gemini neural human voice request failed, falling back to browser human voices:', e);
    }
  }

  // 3. High-Fidelity Natural Human Voice Fallback via Web Speech API
  return playBrowserHumanVoice(text, accent, visemeSequence, options);
}

function playAudioBlob(
  blobUrl: string,
  visemeSequence: VisemeType[],
  options?: {
    rate?: number;
    onViseme?: (v: VisemeType) => void;
    onStart?: () => void;
    onEnd?: () => void;
  }
): Promise<boolean> {
  return new Promise((resolve) => {
    const audio = new Audio(blobUrl);
    currentAudioElement = audio;

    if (options?.rate) {
      audio.playbackRate = options.rate;
    }

    let vIdx = 0;
    audio.onplay = () => {
      options?.onStart?.();
      if (options?.onViseme) {
        visemeInterval = setInterval(() => {
          vIdx = (vIdx + 1) % visemeSequence.length;
          options.onViseme?.(visemeSequence[vIdx]);
        }, 130);
      }
    };

    audio.onended = () => {
      if (visemeInterval) clearInterval(visemeInterval);
      options?.onViseme?.('smile');
      options?.onEnd?.();
      currentAudioElement = null;
      resolve(true);
    };

    audio.onerror = () => {
      if (visemeInterval) clearInterval(visemeInterval);
      options?.onViseme?.('smile');
      options?.onEnd?.();
      currentAudioElement = null;
      resolve(false);
    };

    audio.play().catch((err) => {
      console.warn('Audio element play interrupted or blocked:', err);
      if (visemeInterval) clearInterval(visemeInterval);
      options?.onViseme?.('smile');
      options?.onEnd?.();
      currentAudioElement = null;
      resolve(false);
    });
  });
}

async function playBrowserHumanVoice(
  text: string,
  accent: AccentType,
  visemeSequence: VisemeType[],
  options?: {
    rate?: number;
    pitch?: number;
    onViseme?: (v: VisemeType) => void;
    onStart?: () => void;
    onEnd?: () => void;
  }
): Promise<boolean> {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    options?.onEnd?.();
    return false;
  }

  const voices = await getAvailableVoices();
  const targetLang = accent === 'british' ? 'en-GB' : 'en-US';

  // Prioritize premium, natural human-sounding voices
  // Windows: 'Microsoft George', 'Microsoft Susan', 'Microsoft David', 'Microsoft Mark', 'Microsoft Zira'
  // Apple/macOS/iOS: 'Daniel', 'Oliver', 'Kate', 'Serena', 'Samantha', 'Alex', 'Fred', 'Ava'
  // Google/Chrome: 'Google UK English Male', 'Google US English'
  const matchedVoice =
    voices.find((v) => {
      const name = v.name.toLowerCase();
      const lang = v.lang.toLowerCase();
      if (accent === 'british') {
        return (
          lang.includes('en-gb') &&
          (name.includes('george') ||
            name.includes('oliver') ||
            name.includes('daniel') ||
            name.includes('kate') ||
            name.includes('serena') ||
            name.includes('natural') ||
            name.includes('neural') ||
            name.includes('uk'))
        );
      } else {
        return (
          lang.includes('en-us') &&
          (name.includes('david') ||
            name.includes('alex') ||
            name.includes('samantha') ||
            name.includes('guy') ||
            name.includes('natural') ||
            name.includes('neural') ||
            name.includes('us'))
        );
      }
    }) ||
    voices.find((v) => v.lang.toLowerCase().startsWith(targetLang.toLowerCase())) ||
    voices.find((v) => v.lang.startsWith('en')) ||
    voices[0];

  return new Promise((resolve) => {
    const utterance = new SpeechSynthesisUtterance(text);
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }
    utterance.lang = targetLang;
    utterance.rate = options?.rate || (accent === 'british' ? 0.94 : 0.97);
    utterance.pitch = options?.pitch || (accent === 'british' ? 1.02 : 1.0);

    currentUtterance = utterance;
    let vIndex = 0;

    utterance.onstart = () => {
      options?.onStart?.();
      if (options?.onViseme) {
        visemeInterval = setInterval(() => {
          vIndex = (vIndex + 1) % visemeSequence.length;
          options.onViseme?.(visemeSequence[vIndex]);
        }, 130);
      }
    };

    utterance.onboundary = (e) => {
      if (options?.onViseme && e.name === 'word') {
        const nextChar = text[e.charIndex]?.toLowerCase() || '';
        if (['r'].includes(nextChar)) options.onViseme('bunched_R');
        else if (['t', 'd'].includes(nextChar)) options.onViseme('tongue_T');
        else if (['w', 'u', 'o'].includes(nextChar)) options.onViseme('rounded_W');
        else if (['a'].includes(nextChar)) options.onViseme('open_A');
        else if (['e', 'i'].includes(nextChar)) options.onViseme('wide_E');
        else options.onViseme('open_O');
      }
    };

    utterance.onend = () => {
      if (visemeInterval) clearInterval(visemeInterval);
      options?.onViseme?.('smile');
      options?.onEnd?.();
      currentUtterance = null;
      resolve(true);
    };

    utterance.onerror = () => {
      if (visemeInterval) clearInterval(visemeInterval);
      options?.onViseme?.('neutral');
      options?.onEnd?.();
      currentUtterance = null;
      resolve(false);
    };

    window.speechSynthesis.speak(utterance);
  });
}

